#include "ti_msp_dl_config.h"
#include "Double_ADC.h"
//4046芯片
/*ADC采集引脚
  PA27
  PA16
*/
void setupDMA(DMA_Regs *dma, uint8_t channelNum, unsigned int srcAddr, unsigned int destAddr, unsigned int transferSize)
   {
    DL_DMA_setSrcAddr(dma, channelNum, (unsigned int) srcAddr);//起始地址
    DL_DMA_setDestAddr(dma, channelNum, (unsigned int) destAddr);//结果地址
    DL_DMA_setTransferSize(dma, channelNum, transferSize);//传输大小
    DL_DMA_enableChannel(dma, channelNum);
   }

void ADC_two_Init()
{
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
 
    DL_ADC12_enableConversions(ADC12_0_INST);
    DL_ADC12_enableConversions(ADC12_1_INST);
    DL_TimerA_startCounter(TIMA0);
}
/*
   配置DMA初始化
    ADC0 memory0 PA27 DMAMEM0 DMA_CH0
    ADC1 memory1 PA16 DMAMEM1 DMA_CH1
   配置DMA初始化
    setupDMA(DMA, DMA_CH0_CHAN_ID, (unsigned int) (0x40556280), (unsigned int) &gADCSamples[0][0], ADC_SAMPLE_SIZE);//ADC0
	  setupDMA(DMA, DMA_CH1_CHAN_ID, (unsigned int) (0x40558284), (unsigned int) &gADCSamples[1][0], ADC_SAMPLE_SIZE);//ADC1
    gCheckADC = false;
    ADC_two_Init();//ADC初始化
   开始转换信号
    DL_ADC12_startConversion(ADC12_0_INST);
    DL_ADC12_startConversion(ADC12_1_INST);
*/
