#ifndef __get_ADC_H__
#define __get_ADC_H__
#include "app_con.h"
#include <stdint.h>
// ADC 数据数组（外部定义）
extern volatile uint16_t gADCSamples[ADC_SAMPLE_SIZE];

// 获取峰-峰值对应电压
float get_amplitude_by_rms(void);
float get_FP(uint32_t sample_rate) ;


#endif // __ADC_PROCESS_H__
