#include "get_ADC.h"
#include <math.h>
//获取幅值RMS法、（直接去掉直流偏量）
float get_amplitude_by_rms(void) {
    float sum = 0.0f;
    float sum_sq = 0.0f;

    // Step 1: 计算平均值（DC 偏置）
    for (int i = 0; i < ADC_SAMPLE_SIZE; i++) {
        sum += gADCSamples[i];
    }
    float mean = sum / ADC_SAMPLE_SIZE;//求出波形中心

    // Step 2: 去除偏置后计算平方和
    for (int i = 0; i < ADC_SAMPLE_SIZE; i++) {
        float centered = gADCSamples[i] - mean;  // 去直流偏置
        sum_sq += centered * centered;
    }

    // Step 3: 均方根值
    float mean_sq = sum_sq / ADC_SAMPLE_SIZE;
    float rms = sqrtf(mean_sq);

    // Step 4: 幅值 = RMS × √2
    float amplitude_adc = rms * 1.4142f;

    // Step 5: 转换成电压
    float amplitude_voltage = (amplitude_adc / ADC_RESOLUTION) * VREF;

    return amplitude_voltage;
}
//ADC每1.94us进行一次转换所以转换率的值是515463
float get_FP(uint32_t sample_rate) 
{
    uint16_t threshold = 2048;  // 中轴线
    int first_index = -1;
    int second_index = -1;

    for (int i = 1; i < ADC_SAMPLE_SIZE; i++)
   {
        int prev = gADCSamples[i - 1] > threshold;
        int curr = gADCSamples[i] > threshold;

        if (!prev && curr) {  // 上升沿过零
            if (first_index == -1) {
                first_index = i;
            } else {
                second_index = i;
                break;
            }
        }
    }

    if (first_index != -1 && second_index != -1) 
    {
        int samples_per_cycle = second_index - first_index;
        return (float)sample_rate / samples_per_cycle;
    }

    return 0.0f;  // 没找到周期
}
/*
 while (1) {
        float vpp = get_peak_to_peak_voltage();  // 获取峰-峰电压

        // 显示或打印电压，例如串口或 OLED
        printf("Vpp = %.2f V\r\n", vpp);

        HAL_Delay(500);  // 每500ms更新一次
    }
*/


/*
返回最大，最小，和峰峰值。
void get_peak_info(float *v_max, float *v_min, float *v_pp) {
    uint16_t max_val = 0;
    uint16_t min_val = 4095;

    for (int i = 0; i < ADC_SAMPLE_SIZE; i++) {
        if (gADCSamples[i] > max_val) {
            max_val = gADCSamples[i];
        }
        if (gADCSamples[i] < min_val) {
            min_val = gADCSamples[i];
        }
    }

    *v_max = ((float)max_val / ADC_RESOLUTION) * VREF;
    *v_min = ((float)min_val / ADC_RESOLUTION) * VREF;
    *v_pp  = *v_max - *v_min;
}

*/
/*主函数调用
void display_peak_info(void) {
    float vmax, vmin, vpp;
    get_peak_info(&vmax, &vmin, &vpp);

    // 假设你用 OLED_Printf 函数来显示
    OLED_Clear();
    OLED_Printf(0, 0, "Vmax: %.2f V", vmax);
    OLED_Printf(0, 1, "Vmin: %.2f V", vmin);
    OLED_Printf(0, 2, "Vpp : %.2f V", vpp);
}


*/