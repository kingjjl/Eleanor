#ifndef _app_con_H
#define _app_con_H
//同一定义
#define ADC_SAMPLE_SIZE 1024
#define ADC_RESOLUTION  4095.0f  // 12-bit ADC
#define VREF            3.3f     // 默认参考电压为 3.3V
#define ADC_MAX_2_5V ((uint16_t)(4095.0f * (2.5f / 3.3f)))  //归一化屏幕显示大约是 3103

/* float normX = (float)sample1 / 4095.0f;
  float normY = (float)sample2 / 4095.0f;//参考点这个值对应量化到3.3V
*/
#endif 