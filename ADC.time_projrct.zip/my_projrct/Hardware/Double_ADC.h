#ifndef _Double_ADC_H
#define _Double_ADC_H
#include "ti_msp_dl_config.h"
#include "stdint.h"

void setupDMA(DMA_Regs *dma, uint8_t channelNum, unsigned int srcAddr, unsigned int destAddr, unsigned int transferSize);
void ADC_two_Init();

#endif