/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti/devices/msp/m0p/mspm0g350x.h"
#include "ti/driverlib/dl_timera.h"
#include "ti_msp_dl_config.h"
#include "Hardware/Double_ADC.h"
#include "Hardware/DMA.h"
#include "Hardware/get_ADC.h"
#include "Hardware/OLED.h"
#include "Hardware/OLED_Data.h"
#include "Hardware/app_con.h"
/*在(60, 38)位置显示浮点数字123.45，整数部分长度为3，小数部分长度为2，字体大小为6*8点阵
	//OLED_ShowFloatNum(60, 38, 123.45, 3, 2, OLED_6X8);*/

volatile uint16_t gADCSamples[ADC_SAMPLE_SIZE];  // 存储两个通道的采样数据
volatile uint16_t gADCSamples2[ADC_SAMPLE_SIZE];

volatile bool gCheckADC = true;  // 用于检查DMA传输是否完成
#define OLED_WIDTH 128
#define OLED_HEIGHT 64
uint16_t max = 0, min = 0x0FFF;
float amplitude;//接收幅值
float frequency;//接受频率
 void Lissajousfigure(void)
  {
    uint16_t X, Y;
    uint16_t sample1, sample2;

    const uint16_t lissaWidth = 64;
    const uint16_t lissaHeight = 64;

    uint16_t centerX = OLED_WIDTH - lissaWidth / 2; 
    uint16_t centerY = OLED_HEIGHT / 2;

    OLED_ClearArea(64, 0, 64, 64); 

    for (int i = 0; i < ADC_SAMPLE_SIZE; i++) {
    sample1 = gADCSamples[i];
    sample2 = gADCSamples2[i];

        // 映射 sample 值到 0~1 之间
    //float normX = (float)sample1 / 4095.0f;
    //float normY = (float)sample2 / 4095.0f;//参考点这个值对应量化到3.3V
    float normX = (float)sample1 / ADC_MAX_2_5V;
    float normY = (float)sample2 / ADC_MAX_2_5V;

        // 再映射到 [-1, 1]
    float normalizedX = (normX - 0.5f) * 2.0f;
    float normalizedY = (normY - 0.5f) * 2.0f;

        // 最后映射到显示区域
     int drawX = (int)(centerX + normalizedX * (lissaWidth / 2));
     int drawY = (int)(centerY - normalizedY * (lissaHeight / 2));

     if (drawX >= 64 && drawX < 128 && drawY >= 0 && drawY < 64) {
     OLED_DrawPoint((uint16_t)drawX, (uint16_t)drawY);
     }
     }

     OLED_Update();
  }

 int main(void)
  { 

      SYSCFG_DL_init();
      OLED_Init();
      delay_cycles(1000); 
      OLED_ShowChar(0,0,'f',OLED_8X16);//显示频率f
      OLED_ShowChar(0,22,'A',OLED_8X16);//显示幅度A
      /*以下三个显示的是数字
      OLED_ShowNum(0, 8, 12345, 5, OLED_6X8);
      OLED_ShowNum(0, 28, 12345, 5, OLED_6X8);
      OLED_ShowNum(0, 48, 12345, 5, OLED_6X8);
      
      */
      OLED_Update();

      //配置DMA初始化gADCSamples
      /*
        ADC0 memory0 PA27 DMAMEM0 DMA_CH0
        ADC1 memory1 PA17 DMAMEM1 DMA_CH1
      */
      setupDMA(DMA, DMA_CH0_CHAN_ID, (unsigned int) (0x40556280), (unsigned int) &gADCSamples[0], ADC_SAMPLE_SIZE);//ADC0
      setupDMA(DMA, DMA_CH1_CHAN_ID, (unsigned int) (0x40558284), (unsigned int) &gADCSamples2[0], ADC_SAMPLE_SIZE);//ADC1
      ADC_two_Init();//ADC初始化

      //开始转换信号
      DL_ADC12_startConversion(ADC12_0_INST);
      DL_ADC12_startConversion(ADC12_1_INST);

      while (1) {
        if( gCheckADC == true){
        Lissajousfigure();
        frequency = get_FP(515000);  // 515kHz 1.94us
        amplitude = get_amplitude_by_rms();
        OLED_ShowFloatNum(0,17, frequency, 5, 1, OLED_6X8);
        OLED_ShowFloatNum(0,40, amplitude, 2, 3, OLED_6X8);
        OLED_Update();
        gCheckADC = false;
        DL_TimerA_startCounter(TIMA0);
        delay_cycles(2000);
      }
      
    }
}
void ADC12_0_INST_IRQHandler(void) 
 {
        //if (gCheckADC == true) {
        // return;
      // }
        switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST))
        {
        case DL_ADC12_IIDX_DMA_DONE:
            {
              gCheckADC = true;
              DL_TimerA_stopCounter(TIMA0);
              // process
            }
        break;
        default:
        break;
        }
 }


